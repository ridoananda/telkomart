-- phpMyAdmin SQL Dump
-- version 4.1.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 27, 2021 at 09:00 AM
-- Server version: 5.1.62
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `telkomart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'dandi', 'dandi'),
(3, 'agoy', 'agoy');

-- --------------------------------------------------------

--
-- Table structure for table `alamat`
--

CREATE TABLE IF NOT EXISTS `alamat` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nama_jalan` varchar(30) NOT NULL,
  `nama_kota` varchar(20) NOT NULL,
  `nama_provinsi` varchar(20) NOT NULL,
  `kecamatan` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `alamat`
--

INSERT INTO `alamat` (`id`, `nama_jalan`, `nama_kota`, `nama_provinsi`, `kecamatan`) VALUES
(1, 'jalan kelinci 2 RT.008 RW.015 ', 'Bekasi', 'Jawa Barat', 'Bekasi Utara');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_barang` int(5) NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga_barang` varchar(14) NOT NULL,
  `stok_barang` varchar(12) NOT NULL,
  `gambar_barang` varchar(30) NOT NULL,
  PRIMARY KEY (`id_barang`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `kode_barang`, `nama_barang`, `harga_barang`, `stok_barang`, `gambar_barang`) VALUES
(1, 'MLM1', 'Multimeter Analog', '20000', '3', 'multi1.jpg'),
(2, 'MLM2', 'Multimeter Digital', '30000', '3', 'multi2.jpg'),
(3, 'PSP1', 'Power Supply', '25000', '4', 'pw1.png');

-- --------------------------------------------------------

--
-- Table structure for table `kasir`
--

CREATE TABLE IF NOT EXISTS `kasir` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `id_karyawan` varchar(10) NOT NULL,
  `nama_karyawan` varchar(27) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `kasir`
--

INSERT INTO `kasir` (`id`, `id_karyawan`, `nama_karyawan`, `username`, `password`) VALUES
(1, '2002', 'rizka dandi maulana', 'dandi', 'dandi'),
(3, '1998', 'vyoga', 'agoy', 'agoy');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE IF NOT EXISTS `pesanan` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `barang_id` int(100) NOT NULL,
  `jumlah_barang` int(100) NOT NULL,
  `total_harga` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id`, `barang_id`, `jumlah_barang`, `total_harga`) VALUES
(10, 2, 6, 180000),
(8, 1, 5, 100000),
(6, 2, 5, 150000);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
